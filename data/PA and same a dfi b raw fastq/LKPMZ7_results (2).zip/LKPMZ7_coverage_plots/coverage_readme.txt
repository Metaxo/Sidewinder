We are trialing a new set of coverage plots. These show the relative coverage at each position of the assembly. 
A region with a large gap or a sudden large increase suggests either an assembly issue or a mixture of multiple 
plasmid recombinants.