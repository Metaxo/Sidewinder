These histograms intend to show what fraction of the reads map to the consensus assembly. If greater than 95% of 
a read maps to the consensus sequence, it is colored dark blue. Reads that map to the E. coli genome and not to 
the assembly are marked in orange.

There is currently a known bug where some very large reads will erroneously be mapped to the assembly.
